README

Evan Adamic
adamic.9@buckeyemail.osu.edu
7/9/19

Written and tested using Java 8, on Eclipse Mars 4.5.0

Run on command line: 
	$java Driver (filename)

Assumptions:
	all tokens are considered 'valid' words 
	(e.g., numbers, incorrectly-spelled words, contractions, etc).
	
